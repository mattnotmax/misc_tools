Password: reconstructer.org

30.07.2009

This paper describes all features of the OfficeMalScanner suite in detail. Further i've updated some features since my PH-Neutral talk, fixed bugs and replaced bin2code with MalHost-Setup. A much smarter way to analyze the inner workings of shellcode in a real life session. Both malicious samples described in the paper are included in the package. For sure additionally compressed and with extra password safety.

Analyzing MSOffice malware with OfficeMalScanner.zip

In addition to the paper which describes all features until version 0.431 assure to take a peek at my Hack.Lu 2009 slides as they describe how to use the new "inflate" feature, which is able to inflate and analyze the newer Office XML format.
